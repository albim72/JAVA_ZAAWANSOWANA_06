# hello-world-spring-4
Hello World Example with Spring 4

See more at springframework.guru
